<?php
/**
 * Library which has cache functions to get data
 *
 * @package    Provab Application
 * @subpackage Travel Portal
 * @author     Balu A<balu.provab@gmail.com>
 * @version    V2
 */
class Db_Cache_Api extends CI_Model
{
	function __construct()
	{
		$this->load->helper('custom/db_api');
	}

	private $cache;
	/**
	 * Balu A
	 * get the country details
	 * @param array $from array('k' => 'id', 'v' => 'name')
	 * @param array $condition
	 */
	function get_country_list($from = array('k' => 'origin', 'v' => 'name'), $condition = array('name !=' => ''))
	{
		//Balu A
		return magical_converter($from, $this->cache[$this->set_country_list($condition)]);
	}

	/**
	 * set the country details
	 * @param array $condition
	 */
	function set_country_list($condition)
	{
		$hash_key = hash('md5', __CLASS__ . 'api_country_list' . json_encode($condition));
		if (isset($this->cache[$hash_key]) == false) {
			$this->cache[$hash_key] = $this->custom_db->single_table_records('api_country_list', '*', $condition, 0, 100000000, array('name' => 'ASC'));
		}
		return $hash_key;
	}

	/**
	 * Balu A
	 * get the country details
	 * @param array $from array('k' => 'id', 'v' => 'name')
	 * @param array $condition
	 */
	function get_current_balance()
	{
		//Balu A
		return $this->cache[$this->set_current_balance()];
	}

	/**
	 * set the country details
	 * @param array $condition
	 */
	function set_current_balance()
	{
		$hash_key = hash('md5', __CLASS__ . 'domain_list_balance');
		if (isset($this->cache[$hash_key]) == false) {
			$domain_id = intval(get_domain_auth_id());
			$domain_details = $this->custom_db->single_table_records('domain_list', 'balance', array('origin' => $domain_id));
			$this->cache[$hash_key] = array('value' => $domain_details['data'][0]['balance']);
		}
		return $hash_key;
	}
	/**
	 * Balu A
	 * get the Admin Base Currency
	 */
	function get_admin_base_currency()
	{
		return $this->cache[$this->set_admin_base_currency()];
	}

	/**
	 * Set the Admin Base Currency
	 * @param array $condition
	 */
	function set_admin_base_currency()
	{
		$hash_key = hash('md5', __CLASS__ . 'admin_base_currency');
		if (isset($this->cache[$hash_key]) == false) {
			$domain_id = intval(get_domain_auth_id());
			$query = 'select CC.country as base_currency 
					from domain_list DL
					JOIN currency_converter CC on CC.id=DL.currency_converter_fk
					where origin=' . $domain_id;
			$domain_details = $this->db->query($query)->row_array();
			$this->cache[$hash_key] = $domain_details['base_currency'];
		}
		return $hash_key;
	}

	/**
	 * get the postal code details
	 * @param array $from array('k' => 'id', 'v' => 'name')
	 * @param array $condition
	 */

	function get_postal_code_list($from = array('k' => 'country_code', 'v' => array('name', 'country_code')), $condition = array('name !=' => ''))
	{
		return magical_converter($from, $this->cache[$this->set_country_list($condition)]);
	}

	/**
	 * get the postal code details
	 * @param array $from array('k' => 'id', 'v' => 'name')
	 * @param array $condition
	 */

	function get_country_code_list($from = array('k' => 'country_code', 'v' => array('name', 'country_code')), $condition = array('name !=' => ''))
	{
		return magical_converter($from, $this->cache[$this->set_country_list($condition)]);
	}
	function get_country_code_list_profile($from = array('k' => 'country_code', 'v' => array('name', 'country_code')), $condition = array('name !=' => ''))
	{
		return $this->cache[$this->set_country_list($condition)];
		// return magical_converter($from, $this->cache[$this->set_country_list($condition)]);
	}

	function get_state_list($from = array('k' => 'origin', 'v' => 'en_name'), $condition = array('en_name !=' => ''))
	{

		return magical_converter($from, $this->cache[$this->set_state_list($condition)]);

	}
	function set_state_list($condition)
	{
		$hash_key = hash('md5', __CLASS__ . 'api_state_list' . json_encode($condition));
		if (isset($this->cache[$hash_key]) == false) {
			$this->cache[$hash_key] = $this->custom_db->single_table_records('api_state_list', '*', $condition, 0, 100000000, array('en_name' => 'ASC'));
		}
		return $hash_key;
	}

	/**
	 * get the user type details
	 * @param array $from array('k' => 'id', 'v' => 'name')
	 * @param array $condition
	 */
	function get_user_type($from = array('k' => 'origin', 'v' => array('user_type')), $condition = array('user_type !=' => '', 'origin !=' => ADMIN))
	{
		//FIXME
		if (
			(isset($_GET['domain_origin']) == true && intval($_GET['domain_origin']) > 0) ||
			(isset($_GET['uid']) == true && intval($_GET['uid']) > 0) &&
			$this->entity_user_id == intval($_GET['uid'])
		) {
			//DOMAIN ADMIN CREATION BY PROVAB ADMIN (GET ONLY USER TYPE ADMIN) (OR) EDIT THEIR ACCOUNT
			//checking if it is Superadmin or Sub admin

			if ($this->entity_user_type == ADMIN) {
				$condition = array('user_type !=' => '', 'origin =' => ADMIN);
			} elseif ($this->entity_user_type == SUB_ADMIN) {
				$condition = array('user_type !=' => '', 'origin =' => SUB_ADMIN);
			}

		} else if (get_domain_auth_id() > 0) {
			//DOMAIN USERS CREATION BY DOMAIN ADMIN (GET ALL USER TYPES EXCEPT ADMIN USER TYPE)
			$condition = array('user_type !=' => '', 'origin !=' => ADMIN);
		}
		return magical_converter($from, $this->cache[$this->set_user_type($condition)]);
	}

	/**
	 * set the country details
	 * @param array $condition
	 */
	function set_user_type($condition)
	{
		$hash_key = hash('md5', __CLASS__ . 'user_type' . json_encode($condition));
		if (isset($this->cache[$hash_key]) == false) {
			$this->cache[$hash_key] = $this->custom_db->single_table_records('user_type', '*', $condition, 0, 100000000, array('user_type' => 'ASC'));

		}
		return $hash_key;
	}

	/**
	 * get the continent details
	 * @param array $from array('k' => 'origin', 'v' => 'name')
	 * @param array $condition
	 */
	function get_continent_list($from = array('k' => 'origin', 'v' => 'name'), $condition = array('name !=' => ''))
	{
		return magical_converter($from, $this->cache[$this->set_continent_list($condition)]);
	}

	/**
	 * set the continet details
	 * @param array $condition
	 */
	function set_continent_list($condition)
	{
		$hash_key = hash('md5', __CLASS__ . 'api_continent_list' . json_encode($condition));
		if (isset($this->cache[$hash_key]) == false) {
			$this->cache[$hash_key] = $this->custom_db->single_table_records('api_continent_list', '*', $condition);
		}
		return $hash_key;
	}

	/**
	 * get the city details
	 * @param array $from array('k' => 'id', 'v' => 'destination')
	 * @param array $condition
	 */
	function get_city_list($from = array('k' => 'origin', 'v' => 'destination'), $condition = array('destination !=' => ''))
	{
		return magical_converter($from, $this->cache[$this->set_city_list($condition)]);
	}

	/**
	 * set the city details
	 * @param array $condition
	 */
	function set_city_list($condition)
	{
		$hash_key = hash('md5', __CLASS__ . 'api_city_list' . json_encode($condition));
		if (isset($this->cache[$hash_key]) == false) {
			$this->cache[$hash_key] = $this->custom_db->single_table_records('api_city_list', '*', $condition);
		}
		return $hash_key;
	}
	/**
	 * 	Get Course Type
	 */
	function get_course_type($from = array('k' => 'origin', 'v' => 'name'), $condition = array('name !=' => ''))
	{
		return magical_converter($from, $this->cache[$this->set_course_type($condition)]);
	}

	/**
	 * get course type list
	 */
	function course_type_list($condition)
	{
		return $this->cache[$this->set_course_type($condition)];
	}

	/**
	 * set the course details
	 * @param array $condition
	 */
	function set_course_type($condition)
	{
		$hash_key = hash('md5', __CLASS__ . 'meta_course_list' . json_encode($condition));
		if (isset($this->cache[$hash_key]) == false) {
			$this->cache[$hash_key] = $this->custom_db->single_table_records('meta_course_list', '*', $condition, 0, 100000000, array('priority_number' => 'ASC'));
		}
		return $hash_key;
	}

	/**
	 * 	Get booking source Type
	 */
	function get_booking_source($from = array('k' => 'origin', 'v' => 'name'), $condition = array('name !=' => ''))
	{
		return magical_converter($from, $this->cache[$this->set_booking_source($condition)]);
	}

	/**
	 * set the booking source details
	 * @param array $condition
	 */
	function set_booking_source($condition)
	{
		$hash_key = hash('md5', __CLASS__ . 'booking_source' . json_encode($condition));
		if (isset($this->cache[$hash_key]) == false) {
			$this->cache[$hash_key] = $this->custom_db->single_table_records('booking_source', '*', $condition);
		}
		return $hash_key;
	}

	/**
	 * 	Get Currencies
	 */
	function get_currency($from = array('k' => 'id', 'v' => 'country'), $condition = array('country !=' => ''))
	{
		return magical_converter($from, $this->cache[$this->set_currency($condition)]);
	}

	/**
	 * set theCurrency details
	 * @param array $condition
	 */
	function set_currency($condition)
	{
		$hash_key = hash('md5', __CLASS__ . 'currency_converter' . json_encode($condition));
		if (isset($this->cache[$hash_key]) == false) {
			$this->cache[$hash_key] = $this->custom_db->single_table_records('currency_converter', '*', $condition, 0, 100000000, array('country' => 'ASC'));
		}
		return $hash_key;
	}

	
	/**
	 * 	Get airport code
	 */
	function get_airport_code_list()
	{
		$airport_code_list = $this->cache[$this->set_airport_code_list()];
		$code_list = '';
		if (valid_array($airport_code_list['data'])) {
			foreach ($airport_code_list['data'] as $k => $v) {
				$code_list[$v['city'] . ':(' . $v['code'] . ')'] = $v['city'] . '(' . $v['code'] . ')';
			}
		}
		return $code_list;
	}


	/*
	 * Return Agent List with Agent ID
	 */
	function get_agent_list_with_id($from = array('k' => 'user_id', 'v' => 'agency_name'), $condition = array('agency_name !=' => '', 'user_type' => B2B_USER))
	{
		return magical_converter($from, $this->cache[$this->set_agent_list($condition)]);
	}

	/**
	 * set the country details
	 * @param array $condition
	 */
	function set_agent_list($condition)
	{
		$hash_key = hash('md5', __CLASS__ . 'agent_list' . json_encode($condition));
		if (isset($this->cache[$hash_key]) == false) {
			$this->cache[$hash_key] = $this->custom_db->single_table_records('user', '*', $condition, 0, 100000000, array('agency_name' => 'ASC'));
		}
		return $hash_key;
	}

	function get_group_list($from = array('k' => 'origin', 'v' => 'name'), $condition = array())
	{
		return magical_converter($from, $this->cache[$this->set_group_list($condition)]);
	}

	function set_group_list($condition)
	{
		$hash_key = hash('md5', __CLASS__ . 'user_groups' . json_encode($condition));
		if (isset($this->cache[$hash_key]) == false) {
			$this->cache[$hash_key] = $this->custom_db->single_table_records(
				'user_groups',
				'*',
				$condition,
				0,
				100000000,
				array(
					'origin' => 'ASC'
				)
			);
		}
		return $hash_key;
	}

	function get_distributor_list($from = array('k' => 'user_id', 'v' => array('uuid', 'agency_name')), $condition = array('user_type' => DIST_USER))
	{
		// Arjun J Gowda
		return magical_converter($from, $this->cache[$this->set_distributor_list($condition)]);
	}

	function set_distributor_list($condition)
	{
		$hash_key = hash('md5', __CLASS__ . 'user' . json_encode($condition));
		if (isset($this->cache[$hash_key]) == false) {
			// debug($condition);exit;
			$res['data'] = $this->db->join('dist_user_details', 'dist_user_details.user_oid = user.user_id')->where_in('user.creation_source', [
				'superadmin',
				'admin',
				'subadmin'
			])->get_where('user', $condition)->result_array();
			$res['status'] = SUCCESS_STATUS;
			$this->cache[$hash_key] = $res;
		}
		return $hash_key;
	}

	function get_all_api_country_list($from = array('k' => 'country_code', 'v' => 'country_name'))
	{
		$all_api_country_list = $this->cache[$this->set_all_api_country_list()];
		return magical_converter($from, $all_api_country_list);
	}

	function set_all_api_country_list()
	{
		$hash_key = hash('md5', __CLASS__ . 'all_api_country_list');
		if (isset($this->cache[$hash_key]) == false) {
			$this->db->select('*');
			$this->db->from('all_api_city_master');
			$this->db->order_by('country_name');
			$this->db->group_by('country_name');
			$query = $this->db->get();
			$res['status'] = SUCCESS_STATUS;
			$res['data'] = $query->result_array();
			$this->cache[$hash_key] = $res;
		}
		return $hash_key;
	}

	function get_eco_stays_types($from = array('k' => 'origin', 'v' => 'name'))
	{
		return magical_converter($from, $this->cache[$this->set_eco_stays_types()]);
	}

	function set_eco_stays_types()
	{
		$hash_key = hash('md5', __CLASS__ . 'eco_stays_types');
		if (isset($this->cache[$hash_key]) == false) {
			$res = $this->custom_db->single_table_records('eco_stays_types', '*', array('status' => 1));
			$this->cache[$hash_key] = $res;
		}
		return $hash_key;
	}

	function get_eco_stays_amenities($from = array('k' => 'origin', 'v' => 'name'))
	{
		return magical_converter($from, $this->cache[$this->set_eco_stays_amenities()]);
	}

	function set_eco_stays_amenities()
	{
		$hash_key = hash('md5', __CLASS__ . 'eco_stays_amenities');
		if (isset($this->cache[$hash_key]) == false) {
			$res = $this->custom_db->single_table_records('eco_stays_amenities', '*', array('status' => 1));
			$this->cache[$hash_key] = $res;
		}
		return $hash_key;
	}


	function get_eco_stays_room_types($from = array('k' => 'origin', 'v' => 'name'))
	{
		return magical_converter($from, $this->cache[$this->set_eco_stays_room_types()]);
	}

	function set_eco_stays_room_types()
	{
		$hash_key = hash('md5', __CLASS__ . 'eco_stays_room_types');
		if (isset($this->cache[$hash_key]) == false) {
			$res = $this->custom_db->single_table_records('eco_stays_room_types', '*', array('status' => 1));
			$this->cache[$hash_key] = $res;
		}
		return $hash_key;
	}

	function get_eco_stays_room_amenities($from = array('k' => 'origin', 'v' => 'name'))
	{
		return magical_converter($from, $this->cache[$this->set_eco_stays_room_amenities()]);
	}

	function set_eco_stays_room_amenities()
	{
		$hash_key = hash('md5', __CLASS__ . 'eco_stays_room_amenities');
		if (isset($this->cache[$hash_key]) == false) {
			$res = $this->custom_db->single_table_records('eco_stays_room_amenities', '*', array('status' => 1));
			$this->cache[$hash_key] = $res;
		}
		return $hash_key;
	}

	function get_eco_stays_board_types($from = array('k' => 'origin', 'v' => 'name'))
	{
		return magical_converter($from, $this->cache[$this->set_eco_stays_board_types()]);
	}

	function set_eco_stays_board_types()
	{
		$hash_key = hash('md5', __CLASS__ . 'eco_stays_board_types');
		if (isset($this->cache[$hash_key]) == false) {
			$res = $this->custom_db->single_table_records('eco_stays_board_types', '*', array('status' => 1));
			$this->cache[$hash_key] = $res;
		}
		return $hash_key;
	}

	function get_eco_stays_room_meal_types($from = array('k' => 'origin', 'v' => 'name'))
	{
		return magical_converter($from, $this->cache[$this->set_eco_stays_room_meal_types()]);
	}

	function set_eco_stays_room_meal_types()
	{
		$hash_key = hash('md5', __CLASS__ . 'eco_stays_room_meal_types');
		if (isset($this->cache[$hash_key]) == false) {
			$res = $this->custom_db->single_table_records('eco_stays_room_meal_types', '*', array('status' => 1));
			$this->cache[$hash_key] = $res;
		}
		return $hash_key;
	}

	function get_suppliers($from = array('k' => 'user_id', 'v' => 'user'))
	{
		return magical_converter($from, $this->cache[$this->set_suppliers()]);
	}

	function set_suppliers()
	{
		$hash_key = hash('md5', __CLASS__ . 'suppliers');
		if (isset($this->cache[$hash_key]) == false) {
			$res = $this->custom_db->single_table_records('user', "user_id, CONCAT((first_name), (' '), (last_name)) AS name,  email AS email", array('user_type' => SUPPLIER));

			if($res['status'] == true){
				foreach($res['data'] as $k => $data){
					$res['data'][$k]['user'] = $data['name'] . ' - ' . provab_decrypt($data['email']);
				}
			}
			$this->cache[$hash_key] = $res;
		}
		return $hash_key;
	}

	
}